from flask import Flask, render_template, request
import pymysql
import pygame
file=r'C:\Users\10784\Desktop\test1\Candy Wind.mp3'
pygame.mixer.init()
track = pygame.mixer.music.load(file)

pygame.mixer.music.play()



app = Flask(__name__)
account='1'





def get_cursor():
    config = {
        'host': 'localhost',
        'port': 3306,
        'user': 'root',
        'passwd': 'password',
        'db': 'text1',
        'charset': 'utf8'
    }
    conn = pymysql.connect(**config)
    conn.autocommit(1)  # conn.autocommit(True)
    return conn.cursor()


@app.route('/')
def index():
    return render_template("index.html")

@app.route('/index')
def index2():
    return render_template("index.html")

@app.route('/login', methods=['post'])
def login():
    name = request.form.get("name")
    password = request.form.get("password")
    print(name)
    print(password)
    cursor = get_cursor()  # 打开数据库
    row = cursor.execute("select * from manage where name = %s", (name))  # 获取查询到的信息条数
    if row:
        cursor.execute("select password from manage where name = %s", (name))
        message = cursor.fetchone()
        '''print(message[0])
        print(password)'''
        if password == str(message[0]):
            cursor.execute("select * from list")
            lists = cursor.fetchall()
            return render_template("manage.html", name=name, lists=lists)
        else:
            msg = "密码错误！"
            return render_template("index.html", msg=msg)
    else:#账号不是管理人
        row = cursor.execute("select * from list where id = %s", (name))  # 获取查询到的信息条数
        if row:#是学生，row不为空
            cursor.execute("select password from list where id = %s", (name))
            message = cursor.fetchone()
            if password==str(message[0]):
                cursor.execute("select * from list where id= %s",(name))
                lists = cursor.fetchall()

                cursor.execute("select name from list where id=%s"%name)
                student_name=cursor.fetchone()[0]
                print(student_name)

                cursor.execute("create table if not exists " + ("stu"+name) + " (id_course char(10) not null,name_course char(10),teacher char(10),department char(10),credit double, score double)")
                cursor.execute("select * from grade where id_stu=%s"%name)
                list_course=cursor.fetchall()

                global account#获取全局变量
                account=name
                print(account)

                return render_template("student.html", name=student_name, lists_stu=lists,lists_course=list_course)
            else:
                msg = "密码错误！"
                return render_template("index.html", msg=msg)
        else:
            msg = "您不是管理员！"
            return render_template("index.html", msg=msg)


@app.route('/insert', methods=['post'])
def insert():
    id = request.form.get("id")
    name = request.form.get("name")
    age = request.form.get("age")
    home = request.form.get("home")
    identity = request.form.get("identity")
    password=request.form.get("password")
    sex=request.form.get("sex")
    dorm=request.form.get("dorm")
    grade=request.form.get("grade")

    if (sex=="男"and dorm[0]=="B") or (sex=="女" and dorm[0]=="A"):
        msg = "请不要将男生/女生安排到女生/男生宿舍！"
        return msg
    else:
        value = (id, name, age, home, identity,password,grade,dorm,sex)
        insert_sql = '''INSERT INTO list(id,name, age,home,identity,password,grade,dorm,sex) values (%s,%s,%s,%s,%s,%s,%s,%s,%s)'''
        cursor = get_cursor()  # 打开数据库
        cursor.execute(insert_sql, value)  # 执行sql语句

        #同时创建该学生的课程成绩库
        #cursor.execute("create table if not exists " + ("stu"+id) + " (id_course char(10) not null,name_course char(10),teacher char(10),department char(10),credit double, score double)")

        print(insert_sql, value)
        msg="添加成功！"
        return msg

@app.route('/insert_course', methods=['post'])
def insert_course(id):
    id_course = request.form.get("id_course")
    name_course = request.form.get("name_course")
    teacher = request.form.get("teacher")
    department = request.form.get("department")

    value = (id_course, name_course, teacher, department)

    create_sql='''create table if not exists '''

    insert_sql = '''INSERT INTO list(id,name, teacher,department) values (%s,%s,%s,%s)'''#将数据插入数据库
    cursor = get_cursor()  # 打开数据库

    # 如果没有该学生的数据库，则先创建一个
    # cursor.excute("create table if not exists %s (id_course char(10) not null,name_course char(10),teacher char(10),department char(10))",name)

    cursor.execute(insert_sql, value)  # 执行sql语句
    msg="添加成功！"
    return msg


@app.route('/delete/<int:id>')
def delete(id):
    cursor = get_cursor()  # 打开数据库
    cursor.execute("delete from list where id = %s", (id))  # 删除某一行值

    #同时删除该学生的课程成绩库
    cursor.execute("delete from grade where id_stu=%s"%id)  # 删除某一行值


    msg="删除成功！"
    return msg


@app.route('/update',methods=['post'])
def update():#ID不能修改
    id=request.form.get("id")
    name = request.form.get("name")
    age = request.form.get("age")
    home = request.form.get("home")
    identity = request.form.get("identity")
    password=request.form.get("password")
    sex=request.form.get("sex")
    dorm=request.form.get("dorm")
    if (sex=="男"and dorm[0]=="B") or (sex=="女" and dorm[0]=="A"):
        msg = "请不要将男生/女生安排到女生/男生宿舍！"
        return msg
    else:
        value = (name, age, home, identity,password,dorm,sex,id)
        cursor = get_cursor()  # 打开数据库
        cursor.execute("update list set name = %s,age = %s,home =%s,identity = %s,password=%s,dorm=%s,sex=%s  where id = %s", value)
        msg="编辑成功！"
        return msg

@app.route('/select',methods=['post'])
def select():#查看加权平均绩点
    print("select")
    id=account
    cursor = get_cursor()  # 打开数据库
    cursor.execute("select sum(score*credit)/sum(credit)/20 from grade where id_stu=%s",account)
    avg_score=cursor.fetchone()[0]
    avg_score='%f'%avg_score
    print(avg_score)
    msg="加权学分绩："
    return msg+avg_score

@app.route('/select_stu_score',methods=['post'])
def select_stu_score():#查看加权平均绩点
    print("select_stu_score")
    id=account
    cursor = get_cursor()  # 打开数据库
    cursor.execute("select id_stu,sum(score*credit)/sum(credit)/20 from grade group by id_stu order by sum(score*credit)/sum(credit)/20")#升序排列
    avg_score=cursor.fetchall()
    avg_score
    result=''
    num=len(avg_score)#获取数据记录条目数
    print(num)
    print(avg_score[0][0])
    print(avg_score[0][1])
    for i in range(0,num):
        result=result+avg_score[i][0]+"绩点为："
        result=result+'%f'%avg_score[i][1]+"；\n"
    print(result)
    msg="加权学分绩："
    return result

@app.route('/select_stu_add',methods=['post'])
def select_stu_add():#查看加权平均绩点
    print("select_stu_add")
    id=account
    cursor = get_cursor()  # 打开数据库
    cursor.execute("select count(*),home from list group by home order by count(*)")#升序排列
    avg_score=cursor.fetchall()
    avg_score
    result=''
    num=len(avg_score)#获取数据记录条目数
    print(num)
    print(avg_score[0][0])
    print(avg_score[0][1])
    for i in range(0,num):
        result=result+"城市"
        result=result+avg_score[i][1]+"的生源数为："
        result=result+'%d'%avg_score[i][0]+"；\n"
    print(result)
    msg="加权学分绩："
    return result

if __name__ == '__main__':
    app.run()
